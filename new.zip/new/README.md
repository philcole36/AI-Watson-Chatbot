# Learncode | A Feature-Incomplete Codecademy type clone

![Apache License](https://img.shields.io/github/license/matt-allen44/learncode.svg)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

### Quick start
> install a PHP server (eg. the LAMP stack)

> point it to the www directory

> access the server through your browser

## Screenshots
### Homepage
![Homepage](http://i.imgur.com/fPxqCaO.png)
### Task Selection Screen
![Task Selection Screen](http://i.imgur.com/fbhFkni.png)
### Code Editor Screen
![IDE Screen](http://i.imgur.com/uo0bPfV.png)


### Contributing
> This project is not open for contribution as it was completed as a school project
> Feel free to fork if you wish!
