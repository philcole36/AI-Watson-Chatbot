<html>
	<body style="background-color:#272822">
		<h2 style="color: #fff; font-size: 20rem; text-align: center; padding-top: 15%; margin-bottom: 0px"> 404 </h2>
	<script>
			setTimeout(redirect, 0);

			function redirect(){
				window.location.replace("selecttask.php");
			}
		</script
	</body>
</html>